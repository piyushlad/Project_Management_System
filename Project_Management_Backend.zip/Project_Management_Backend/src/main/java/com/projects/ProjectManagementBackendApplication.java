package com.projects;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectManagementBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectManagementBackendApplication.class, args);
		
	}

}
