import logo from './logo.svg';
import './App.css';
import Navbar from './component/navbar';
import { Route, Routes } from 'react-router-dom';
import Home from './component/Home';
import AddProduct from './component/AddProduct';
import EditProduct from './component/EditProduct';
import ContactUs from './component/ContactUs';

function App() {
  return (
    
<><Navbar />
    <Routes>
      <Route path='/' element={<Home/>}></Route>
      <Route path='/addProduct' element={<AddProduct/>}></Route>
      <Route path='/editProduct/:id' element={<EditProduct/>}></Route>

      <Route path='/contactUs' element={<ContactUs/>}></Route>
    </Routes>
    </>
  );
}

export default App;
