import React from 'react'
const ContactUs = () =>{
    return (
        <>
<h1>Contact Us</h1>
        </>
    )
}
export default ContactUs